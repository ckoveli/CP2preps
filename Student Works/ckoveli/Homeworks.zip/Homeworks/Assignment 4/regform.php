<?php 
printf("jajajaj");
//Velickovic Djordje
?>
