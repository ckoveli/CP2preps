// Velickovic Djordje

var score = localStorage.getItem("scorevalue");
var player = localStorage.getItem("tplayervalue");
var player2 = localStorage.getItem("tplayervalue2");

for(let i = 1; i < 8; i++){
    if(player === "" || player === null){

    break;
}if(player !== "" || player !== null){
    document.getElementById("score" +i).innerText = player+ ": " +score;

    break;
}
if(player2 !== player){
    var j = i + 1;
    document.getElementById("score" +j).innerText = player2+ ": " +score;

    break;
}else{
    document.getElementById("score" +i).innerText = player2+ ": " +score;

    break;
}
}
function resetScore(){
    document.querySelector(".options").style.display = "none";
    document.getElementById("resetBtn").style.display = "none";
    document.querySelector(".playerName").style.display = "block";
    document.getElementById("playerName").style.display = "block";
    document.getElementById("inputHolder").style.display = "block";
    document.getElementById("okBtn").style.display = "block";
    document.getElementById("cancelBtn").style.display = "block";
}
function okay(){
    document.querySelector(".options").style.display = "block";
    document.getElementById("resetBtn").style.display = "block";
    document.querySelector(".playerName").style.display = "none";
    document.getElementById("playerName").style.display = "none";
    document.getElementById("inputHolder").style.display = "none";
    document.getElementById("okBtn").style.display = "none";
    document.getElementById("cancelBtn").style.display = "none";

    var playerName = document.getElementById("playerName").value;

    if(document.getElementById("score1" && "score2" && "score3" && "score4" && "score5" && "score6" && "score7").innerText !== playerName +": " +score){
        document.getElementById("inputHolder").style.color = "red";
        document.getElementById("inputHolder").innerText = "No such player: \""  +playerName+ "\".";

        document.querySelector(".options").style.display = "none";
        document.getElementById("resetBtn").style.display = "none";
        document.querySelector(".playerName").style.display = "block";
        document.getElementById("playerName").style.display = "block";
        document.getElementById("inputHolder").style.display = "block";
        document.getElementById("okBtn").style.display = "block";
        document.getElementById("cancelBtn").style.display = "block";
        }
    for(let i = 1; i < 8; i++){
        if(document.getElementById("score" +i).innerText === playerName +": " +score){
            document.getElementById("score" +i).innerText = "";
            document.getElementById("playerName").value = "";
            localStorage.removeItem("tplayervalue");

            document.querySelector(".options").style.display = "block";
            document.getElementById("resetBtn").style.display = "block";
            document.querySelector(".playerName").style.display = "none";
            document.getElementById("playerName").style.display = "none";
            document.getElementById("inputHolder").style.display = "none";
            document.getElementById("okBtn").style.display = "none";
            document.getElementById("cancelBtn").style.display = "none";

            document.getElementById("inputHolder").style.color = "white";
            document.getElementById("inputHolder").innerText = "Player name:";
        }
    }
}
function cancel(){
    document.querySelector(".options").style.display = "block";
    document.getElementById("resetBtn").style.display = "block";
    document.querySelector(".playerName").style.display = "none";
    document.getElementById("playerName").style.display = "none"; document.getElementById("playerName").value = "";
    document.getElementById("inputHolder").style.color = "white";
    document.getElementById("inputHolder").innerText = "Player name:"
    document.getElementById("inputHolder").style.display = "none";
    document.getElementById("okBtn").style.display = "none";
    document.getElementById("cancelBtn").style.display = "none";
}

// Velickovic Djordje