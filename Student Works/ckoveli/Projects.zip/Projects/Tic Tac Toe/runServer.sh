#!/bin/bash

echo "";
cd /Users/artvel/Desktop/Famnit/'Semester II'/'Computer Practicum II'/Projects/'Tic Tac Toe'/game/multiPlayer/server;
node server.js;
