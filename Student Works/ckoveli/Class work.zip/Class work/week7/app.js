var person = prompt("Enter your name");
var counter = 2;

if(person == null || person == ""){
	prompt("Enter your name I said.");
	counter--;
	if(counter == 1){
		prompt("YOUR NAME!");
		counter--;
	}if(counter == 0){
		alert("That's it, leave this page NOW!");

	}
} else{
	prompt("How old are you?");
	document.getElementById("result").innerHTML = "Hello" +person+ "! How are you today?";
}
